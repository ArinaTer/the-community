import imagesLoaded from 'imagesloaded'
import * as myFunctions from './modules/functions.js';
import * as bootstrap from 'bootstrap';

import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger.js";
import { ScrollToPlugin } from "gsap/ScrollToPlugin.js"
import SmoothScroll from 'smoothscroll-for-websites'
import Swiper, { Navigation, Pagination, Autoplay, EffectFade, EffectCoverflow, Thumbs, Controller } from 'swiper';
import lightGallery from 'lightgallery'
import lgVideo from 'lightgallery/plugins/video/lg-video.min.js'
import lgThumbnail from 'lightgallery/plugins/thumbnail/lg-thumbnail.min.js'
import lgMediumZoom from 'lightgallery/plugins/mediumZoom/lg-medium-zoom.min.js'

gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

myFunctions.isWebp();

// Preload transform
// window.setTimeout(function () {
//     document.body.classList.add("loaded");
//     document.scrollingElement.scrollTo(0, 0);
//     gsap.to(document.querySelector(".preload"), { autoAlpha: 0 });

// }, 6000)

ScrollTrigger.saveStyles(".panel2, .main-about__container, .main-about__offers, .main-about__text, .main-about__info, #main-about__title, .main-about__clouds, .main-abot__top, .main-about__center .main-about__bottom")

const images = gsap.utils.toArray("img");
const loader = document.querySelector(".preload");
const showDemo = () => {

    // Preload transform

    document.body.classList.add("loaded");
    document.scrollingElement.scrollTo(0, 0);
    gsap.to(document.querySelector(".preload"), { autoAlpha: 0 });

    // lightGallery

    const lg = document.querySelectorAll('.lg-list')
    lg.forEach(item => {
        lightGallery(item, {
            plugins: [lgVideo, lgThumbnail],
            videojs: true,
            licenseKey: 'your_license_key',
            selector: '.lg-item',
            mode: 'lg-slide',
            speed: 800,
            loop: false,
            counter: false,
            download: false,
            thumbnail: true,
            mobileSettings: {
                showCloseIcon: true
            }
        })
    })

    //Pop-up-modal

    const seconds = 40000;
    const timer = setTimeout(function () {
        const myModal = new bootstrap.Modal(document.getElementById('popupModal'));
        myModal.show();
    }, seconds);
    const modal = document.querySelectorAll('.modal')
    modal.forEach(function (el) {
        el.addEventListener('show.bs.modal', function () {
            clearTimeout(timer)
        });
    });
    var mSuc = new URLSearchParams(window.location.search).get("success"); if (mSuc) { if ("1" === mSuc) new $i(document.getElementById("thankYouModal"), {}).show(); history.pushState({}, null, location.href.split("?")[0]) };

    SmoothScroll({
        animationTime: 2000,
        stepSize: 80,
        keyboardSupport: true,
        arrowScroll: 100,
        touchpadSupport: true
    })

    // Slide hover

    const sliderItems = document.querySelectorAll('.main-slide-hover__item');
    const sliderWrapper = document.querySelector('.main-slide-hover__img .swiper');
    const swiper = new Swiper(sliderWrapper, {
        modules: [EffectFade],
        effect: "fade",
        mousewheel: true,
        keyboard: true,
    });

    sliderItems.forEach((item) => {
        item.addEventListener('mouseenter', toggleActive);
    });

    function toggleActive() {
        const index = [...sliderItems].indexOf(this);
        sliderItems.forEach((item) => {
            item.classList.remove('active');
        });

        this.classList.add('active');
        swiper.slideTo(index);
    }


    // Add class Gallery

    const galCon = document.querySelector('.main-gallery__container')
    const btnExtr = document.getElementById('openExterior');
    const btnInter = document.getElementById('openInterior');
    const btnCloseEx = document.getElementById('close-exteriors');
    const btnCloseIn = document.getElementById('close-interiors');


    btnExtr.addEventListener('click', function () {
        this.classList.add('active');
        galCon.classList.add('show-exteriors');
    });
    btnInter.addEventListener('click', function () {
        this.classList.add('active');
        galCon.classList.add('show-interiors');
    });

    btnCloseEx.addEventListener('click', function () {
        btnExtr.classList.remove('active');
        galCon.classList.remove('show-exteriors');
    });
    btnCloseIn.addEventListener('click', function () {
        btnInter.classList.remove('active');
        galCon.classList.remove('show-interiors');
    });

    ScrollTrigger.matchMedia({
        "all": function () {

            //Navbar

            let bodyOverlay = document.createElement('div');
            bodyOverlay.classList.add('body-overlay')
            document.body.append(bodyOverlay);

            const tlMenu = gsap.timeline({ paused: true });

            tlMenu.to(".main-nav__menu", { yPercent: 100, opacity: 1 })
                .to(".body-overlay", { visibility: "visible", autoAlpha: 1 }, 0)
                .to(".main-nav__burger-line_mid", { width: 0 }, 0)
                .to(".main-nav__burger-line_top", { y: 8 }, 0)
                .to(".main-nav__burger-line_bot", { y: -6 }, 0)
                .to(".main-nav__burger-line_top", { rotate: 45 }, 0.5)
                .to(".main-nav__burger-line_bot", { rotate: -45 }, 0.5)
                .from(".menu__item", { autoAlpha: 0, stagger: 0.05 }, 0.6)

            const btnToggler = document.querySelector(".btn-toggler");
            btnToggler.addEventListener("click", toggleMenu);
            document.querySelector(".body-overlay").addEventListener("click", toggleMenu);
            function toggleMenu() {
                tlMenu.reversed() ? tlMenu.timeScale(1).play() : tlMenu.timeScale(2).reverse();
                btnToggler.classList.toggle('open')
                document.querySelector(".main-nav").classList.toggle('show')
            }
            tlMenu.reverse();

            // Panel animation scroll

            gsap.utils.toArray(".panel").forEach((panel, i) => {
                ScrollTrigger.create({
                    trigger: panel,
                    start: "bottom bottom",
                    pin: true,
                    pinSpacing: false,
                });
            });

            // Panel animation scroll

            gsap.utils.toArray(".panel2").forEach((panel2, i) => {
                ScrollTrigger.create({
                    trigger: panel2,
                    start: "top top",
                    pin: true,
                    pinSpacing: false,
                });
            });

            // Key anim

            ScrollTrigger.create({
                trigger: ".main-key-features",
                start: "top 100px",
                end: "bottom bottom-=100px",
                onEnter: () => firstSwiper(),
            });


        },
        "(min-width: 821px)": function () {
            // Main about anim

            const tlanimAbout = gsap.timeline({
                scrollTrigger: {
                    trigger: ".main-about__container",
                    scrub: 3,
                    start: "top 80%",
                },
            });

            tlanimAbout.from("#main-about__title", { yPercent: -800, duration: 5 }, 1)
                .from(".main-about__text", { yPercent: 500, duration: 5 }, 1)
                .from(".main-about__bottom", { yPercent: 100, duration: 10, }, 2)
                .from(".main-about__clouds", {
                    scrollTrigger: {
                        trigger: ".main-about__container",
                        start: "top top",
                    },
                    yPercent: 400, duration: 10
                }, 3)
                .from(".main-about__center", { yPercent: -800, duration: 10 }, 4)
                .from(".main-abot__top", { yPercent: -800, duration: 10 }, 5)
                .to(".main-about__info", { xPercent: 100, duration: 10, }, 8)
                .to(".main-about__offers", { yPercent: -100, duration: 5, opacity: 1 }, 16)
        },
        "(max-width: 820px)": function () {
            // Main about anim

            const tlanimAbout = gsap.timeline({
                scrollTrigger: {
                    trigger: ".main-about__container",
                    scrub: 3,
                    start: "top 80%",
                },
            });

            tlanimAbout.from("#main-about__title", { yPercent: -800, duration: 5 }, 1)
                .from(".main-about__text", { yPercent: 500, duration: 5 }, 1)
                .from(".main-about__bottom", { yPercent: 100, duration: 10, }, 2)
                .from(".main-about__clouds", {
                    scrollTrigger: {
                        trigger: ".main-about__container",
                        start: "top top",
                    },
                    yPercent: 400, duration: 10
                }, 3)
                .from(".main-about__center", { yPercent: -800, duration: 10 }, 4)
                .from(".main-abot__top", { yPercent: -800, duration: 10 }, 5)
                .to(".main-about__info", { yPercent: 100, duration: 10, }, 8)
                .to(".main-about__offers", { yPercent: -100, duration: 5, opacity: 1 }, 16)

        },
        "(min-width: 992px)": function () {


            // Main brochure
            gsap.from(".main-brochure__img-top", {
                scrollTrigger: {
                    trigger: ".main-brochure__container",
                    start: "top 100%",
                    end: "bottom bottom",
                    scrub: 3,
                },
                x: 300,
            })

            const tlLolc = gsap.timeline({
                scrollTrigger: {
                    trigger: ".main-location__container",
                    scrub: true,
                    start: "top top",

                },
            });

            tlLolc.to(".main-location__list", { yPercent: -53, })


            gsap.utils.toArray(".main-location__item-wrapper-anim").forEach(function (elem) {
                gsap.timeline({
                    scrollTrigger: {
                        trigger: elem,
                        start: "top 30%",
                        end: "top 30%",
                        scrub: 1
                    }
                }).to(elem, { opacity: 0, scale: 0.8, duration: 10 })
            })
        },
    })


    function firstSwiper() {
        //Swiper key features
        document.querySelectorAll('.main-key-features .swiper').forEach(function (el, index) {
            const swiper = new Swiper(el, {
                modules: [Navigation],
                slidesPerView: 1,
                spaceBetween: 30,
                centeredSlides: true,
                // Navigation arrows
                navigation: {
                    prevEl: '.main-key-features .forSwiper .swiper-button-next',
                    nextEl: '.main-key-features .forSwiper .swiper-button-prev',
                },
            });
        });
    }
    //Swiper slide-hover
    document.querySelectorAll('.main-slide-hover__slide-mobile .swiper').forEach(function (el, index) {
        const swiper = new Swiper(el, {
            modules: [Navigation],
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto",
            // Navigation arrows
            navigation: {
                prevEl: '.main-slide-hover__slide-mobile .forSwiper .slide-button-next',
                nextEl: '.main-slide-hover__slide-mobile .forSwiper .slide-button-prev',
            },
        });
    });

    //Swiper exterior
    document.querySelectorAll('.modal-exterior .swiper').forEach(function (el, index) {
        const swiper = new Swiper(el, {
            modules: [Navigation, EffectCoverflow],
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto",
            coverflowEffect: {
                rotate: 0,
                stretch: 0,
                depth: 200,
                modifier: 1,
                slideShadows: true,
            },
            // Navigation arrows
            navigation: {
                prevEl: '.modal-exterior .forSwiper .modal-exterior-btn-prev',
                nextEl: '.modal-exterior .forSwiper .modal-exterior-btn-next',
            },
        });
    });

    // Swiper interior
    document.querySelectorAll('.modal-interior .swiper').forEach(function (el, index) {
        const swiper = new Swiper(el, {
            modules: [Navigation, EffectCoverflow],
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto",
            coverflowEffect: {
                rotate: 0,
                stretch: 0,
                depth: 200,
                modifier: 1,
                slideShadows: true,
            },
            // Navigation arrows
            navigation: {
                prevEl: '.modal-interior .forSwiper .modal-interior-btn-prev',
                nextEl: '.modal-interior .forSwiper .modal-interior-btn-next',
            },
        });
    });


    const multipleSwiperSlides = function () {
        let sliderMain = document.querySelectorAll('.swiper-top')
        let sliderNav = document.querySelectorAll('.swiper-thumb')

        // Arrays to hold swiper instances
        let mainArray = [];
        let navArray = [];

        // Slider Main
        sliderMain.forEach(function (element, i) {
            // Push swiper instance to array
            mainArray.push(
                new Swiper(element, {
                    modules: [Controller, EffectFade],
                    // loop: true,
                    effect: "fade",
                    loopedSlides: 1,
                })
            );
        });

        // Slider Nav
        sliderNav.forEach(function (element, i) {
            var self = sliderNav;
            // Push swiper instance to array
            navArray.push(
                new Swiper(element, {
                    modules: [Navigation, Controller, EffectFade],
                    slidesPerView: 1,
                    effect: "fade",
                    // loop: true,
                    loopedSlides: 1,
                    slideToClickedSlide: true,
                    spaceBetween: 5,
                    navigation: {
                        nextEl: ".forSwiper .floor-btn-next",
                        prevEl: ".forSwiper .floor-btn-prev",
                    },
                })
            );
        });

        const checkOnPage = function () {
            if (sliderMain.length > 0 && sliderNav.length > 0) {
                let numberOfSlides = mainArray.length || navArray.length || 0;

                if (mainArray.length !== navArray.length) {

                }

                for (let i = 0; i < numberOfSlides; i++) {
                    mainArray[i].controller.control = navArray[i];
                    navArray[i].controller.control = mainArray[i];
                }


            }
        }

        checkOnPage();
    }

    multipleSwiperSlides();


    // Swiper offer
    document.querySelectorAll('.main-slide-offers__container .swiper').forEach(function (el, index) {
        const swiper = new Swiper(el, {
            modules: [Navigation, Autoplay],
            slidesPerView: 1,
            spaceBetween: 30,
            watchSlidesProgress: true,
            breakpoints: {
                0: {
                    slidesPerView: 1,
                },
                821: {
                    slidesPerView: 3,
                },
            },
            autoplay: {
                delay: 4500,
                disableOnInteraction: false,
            },
            // Navigation arrows
            navigation: {
                prevEl: '.main-slide-offers__container .forSwiper .offer-btn-prev',
                nextEl: '.main-slide-offers__container .forSwiper .offer-btn-next',
            },
        });
    });

}
setTimeout(() => imagesLoaded(images).on("progress").on("always", showDemo), 6000)
